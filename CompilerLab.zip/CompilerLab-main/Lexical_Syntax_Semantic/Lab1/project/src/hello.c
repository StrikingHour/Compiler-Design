#include "helloprint.h"
int main()
{
    print();
}