#include "helloprint.h"
int main()
{
    printf("Hello world\n");
}