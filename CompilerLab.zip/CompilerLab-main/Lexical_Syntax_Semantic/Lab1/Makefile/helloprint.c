#include<stdio.h>
#include "helloprint.h"
void print(){
    printf("Hello world from makefile\n");
}