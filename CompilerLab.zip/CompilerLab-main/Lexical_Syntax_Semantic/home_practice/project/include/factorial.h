#pragma once
#ifndef FACTORIAL_H
#define FACTORIAL_H

long long fact(int);

#endif