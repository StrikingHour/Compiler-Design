#include<stdio.h>
#define N 10
#define fr(i,j) for(i=0;i<j;i++)
int main()
{
    int a = N, b = 20, c=0;
    printf("%d\n", b-a);
}
